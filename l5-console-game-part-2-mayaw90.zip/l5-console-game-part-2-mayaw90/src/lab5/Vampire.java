package lab5;

public class Vampire extends Enemy {
	public Vampire(String name, int xLocation, int yLocation) {
        super(name, xLocation, yLocation);
        this.setCurrentHitPoints(10);
        this.setWeaponDamage(4);
    }

    @Override
    public void move() { // twice the speed of the enemy
        if (this.getCurrentHitPoints() > 0) {
            int direction = rand.nextInt(4);
            switch (direction) {
            case 0:
                this.setLocationY(this.getLocationY() + 2);
                break;
            case 1:
                this.setLocationY(this.getLocationY() - 2);
                break;
            case 2:
                this.setLocationX(this.getLocationX() - 2);
                break;
            case 3:
                this.setLocationX(this.getLocationX() + 2);
                break;
            case 4:
                this.specialAbility();
                break;
            }
        }
    }

    @Override
    public void specialAbility() {
        System.out.printf("%s, The Vampire, used special ability, and increased their damage by 3.\n", this.getName());
        this.setWeaponDamage(this.getWeaponDamage() + 3);
    }

}
