package assignment;

public class Score {	
	//private member variables
	private String scoreName;
	private double scoreVal;
	/**
	 * Score cannot be less than zero or higher than 100
	 * Score name cannot be null. If null, set name to ""
	 * @param scoreName
	 * @param score
	 */
	public Score(String scoreName, double scoreVal) {
		this.setScoreName(scoreName);
		this.setScoreValue(scoreVal);
	}
	/**
	 * @return the score
	 */
	public double getScoreValue() {
		return scoreVal;
	}
	/**
	 * Score cannot be less than zero or higher than 100.00
	 * @param scoreVal the score to set
	 * @return true if score within range.
	 */
	public boolean setScoreValue(double scoreVal) {
		if (scoreVal < 0 || scoreVal > 100) {
			return false;
		}
		else {
			this.scoreVal = scoreVal;
			return true;
		}
	}
	/**
	 * @return the scoreName
	 */
	public String getScoreName() {
		return scoreName;
	}
	/**
	 * Score name cannot be null. If null, set name to ""
	 * @param scoreName the scoreName to set
	 */
	public boolean setScoreName(String scoreName) {
		if(scoreName == null) {
			this.scoreName = "";
			  return false;
		}
		else {
			this.scoreName = scoreName;
			return true;
		}
	}
	
	/**
	 * toString method
	 * Examples of return:
	 * "Score [scoreName=qu12, score=96.0]"
	 * "Score [scoreName=Quiz1, scoreValue=100.0]"
	 * "Score [scoreName=Quiz23, scoreValue=22.33]"
	 * @return String representation of Score object
	 */
	@Override
	public String toString() {
		return "Score [scoreName=" + scoreName + ", score=" + this.scoreVal + "]";
	}

}