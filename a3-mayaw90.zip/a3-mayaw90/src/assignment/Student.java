
package assignment;

public class Student {
      /**
       * Use an array to store Score objects for the quizzes
       * A student has at most 10 Quiz scores
       */
      // member variables
	
      private static int numberOfStudentobjects = 0;
      Score scoreObjects[] = new Score[10];
      String stuName;
      int stuId;
      Score score;
      int scoreCounter = 0;
      private Score[] arrayOfScores;
      
      /**
       * Constructor
       * A student has at most 10 Quiz scores
       * @param id The student's ID.
       * @param stuName The student's name.
       */
      public Student(String stuName, int stuID) {
            this.stuId = stuID;
            this.stuName = stuName;
            numberOfStudentobjects++;
      }
      /**
       * @return the array with all My Quiz Scores
       */
      public Score[] getAllMyScores() {
           return scoreObjects;
      }
           
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public Score getScore() {
		return score;
	}
	public void setScore(Score score) {
		this.score = score;
	}

	/**
       * @param an array with Quiz Scores used to set my current quiz scores
       */
      public void setAllMyScores(Score[] arrayOfScores) {
    	  this.scoreObjects = arrayOfScores;
      }
      /**
       * toString method
       * Example return:
       * "Bugsy 123456"
       * @return A string with the student's ID number
       * and name.
       */
      public String toString() {
            return stuName + " " + stuId;
      }
      /**
       * equals method
       * @param another Student object (remember to cast)
       * @return A boolean - true if this student's ID number
       * and name matches this student's ID number and name.
       */
      @Override
      public boolean equals(Object that) {
    	  Student tempCast = (Student)that;
    	  
    	  if(this.stuName.equals(tempCast.getStuName()) && this.stuId == getStuId()) {
    		  return true;
    	  }else {
    		  return false;
    	  }
      }
      /**
       * updateScore method
       * @param scoreName - name of the Score object to search for and update
       * @param newScoreVal - new value for the searched quiz.
       * @return A boolean - true if the quizName already exist for this student
       * and the score is valid and the score array was successfully updated.
       */
      public boolean updateAScore(String scoreName, double newScoreVal) {
            // check scoreName is valid
            if (scoreName == null) {
            	return false;
            }
            	for(int i = 0; i <scoreObjects.length; i++) {
            		if(scoreObjects[i] != null) {
            			if(scoreObjects[i].getScoreName().equals(scoreName)) {
            				scoreObjects[i].setScoreValue(newScoreVal);
            				return true;
            			}
            		}
            	}
            return false;
      }
      /**
       * AddScore method
       * @param newScore - the Score object to Add.
       * @return A boolean - true if the quizName didn't exist for this student
       * and the score is valid and the score array was successfully updated.
       */
      public boolean AddScore(Score newScore) {
            // if not valid score
            if (newScore == null) {
                return false;
            }
            
            for (int i = 0; i < scoreObjects.length; i++) {
            	if(scoreObjects[i] != null) {
                  if (scoreObjects[i].getScoreName() == newScore.getScoreName()) {
                	  return false;
                  }
             }
      }
            for(int i = 0; i < scoreObjects.length; i++) {
            	if (scoreObjects[i] == null) {
            		scoreObjects[i] = newScore;
            	}
            }
            return true;
      }
      /**
       * @param scoreName - name of quiz to get score
       * @return the score for the quiz or -1 if quizName is invalid
       */
      public double getAScore(String scoreName) {
            if(scoreName == null) {
            	return -1;
            }
            for(int i = 0; i < scoreObjects.length; i++) {
            	if(scoreObjects[i] != null) {
            		if(scoreObjects[i].getScoreName().equals(scoreName)) {
            			return scoreObjects[i].getScoreValue();
            		}
            	}
            }
            return -1;
      }
      /**
       * computeMyAverage method
       * Computes the average of the valid scores in this student's array
       * e.g. - student array -> {50, null, 100, null, 150}, the average would be 100
       * @return this student's average score
       */
      public double computeMyAverage() {
            double sum = 0;
            int count = 0;
            // loop over all scores
            for (int i = 0; i < scoreObjects.length; i++) {
                  // if not a valid score, continue loop
                  if (scoreObjects[i] == null) continue;
                  if (scoreObjects[i].getScoreValue() == -1) continue;
                  // add to sum
                  sum += scoreObjects[i].getScoreValue();
                  // increment count
                  count++;
            }
            // if valid score exists
            if (count > 0)
                  return sum / count;
            return -1.0;
      }
      /**
       * getNumberOfStudentsCreated method
       * Keeps track of the number of Student instances
       * @return the total number of Student objects instantiated
       */
      public static int getNumberOfStudentsCreated() {
            return numberOfStudentobjects;
      }
      /**
       * @return the stuName
       */
      public String getStuName() {
            return stuName;
      }
      /**
       * @param stuName the stuName to set
       */
      public void setStuName(String stuName) {
            this.stuName = stuName;
      }
      /**
       * @return the id
       */
      public int getId() {
            return stuId;
      }
}
