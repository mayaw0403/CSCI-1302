package assignment;

import java.util.ArrayList;

public class Course {
	
	 ArrayList<Student> allStudents;
	 
	 //default constructor
	 public Course() {
		 allStudents = new ArrayList<Student>();
	 }
	    /**
	     * @return the allStudents
	     */

	    public ArrayList<Student> getAllStudents() {
	        return allStudents;
	    }

	    /**
	     * @param allStudents the allStudents to set
	     */

	    public void setAllStudents(ArrayList<Student> allStudents) {
	        this.allStudents = allStudents;
	    }

	    // addStudent method 
	    public boolean addStudent(Student stu) {
	        if(stu==null){
	            return false;
	        }
	        
	        for(Student student: allStudents){
	            if(student.equals(stu)){
	                return false;
	            }
	        }
	        
	        return allStudents.add(stu);
	    }

	    // Remove student method 
	    public boolean removeStudent(Student stu) {
	        if(stu==null){
	            return false;
	        }

	        for(Student student : allStudents){
	            if(student.equals(stu)){
	                return allStudents.remove(stu);
	            }
	        }

	        return false;
	    }

	    // Update student method 
	    public boolean updateStudent(Student stu) {
	        if(stu==null){
	            return false;
	        }
	        if(allStudents.contains(stu)){
	        	allStudents.set(allStudents.indexOf(stu), stu);
	                return true;
	            }

	        return false;
	    }

	    /**

	     *

	     * @return the average of all the student's quizzes

	     */

	    public double computeCourseAverage() {
	    	double scoresAvgSum = 0.0;
	    	int totalScores = 0;
	        for(int i = 0;i<allStudents.size();i++){
	        	if(allStudents.get(i) != null) {
	        		Score[] studentScores = allStudents.get(i).getAllMyScores();
	        		
	        		for(int j = 0; j < studentScores.length; j++) {
	        			if(studentScores[j] != null) {
	        				scoresAvgSum += studentScores[j].getScoreValue();
	        				totalScores++;
	        			}
	        		}
	        	}
	        }

	        return scoresAvgSum/totalScores;
	    }
}