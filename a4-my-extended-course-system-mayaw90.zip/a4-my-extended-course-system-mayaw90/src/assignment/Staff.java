
package assignment;
import java.util.ArrayList;

public class Staff {
	
	private ArrayList<Employee> allEmployees = new ArrayList<Employee>();

    /**
     * @return the allEmployees
     */
    public ArrayList<Employee> getAllEmployees() {
        return allEmployees;
    }

    /**
     * @param allEmployees the allEmployees to set
     */
    public void setAllEmployees(ArrayList<Employee> allEmployees) {
        this.allEmployees = allEmployees;
    }

    public void addEmployee(Employee worker) {
        this.allEmployees.add(worker);
    }
    
    public String toStringOnlyStudentWorkers() {
        String out = "";
        for(int i=0; i< this.allEmployees.size(); i++) {
            if(this.allEmployees.get(i) instanceof StudentWorker) {
                out+=this.allEmployees.get(i)+"\n";
            }
        }
        return out;
    }

    public String toStringOnlyTempWorkers() {
        String out = "";
        for(int i=0; i< this.allEmployees.size(); i++) {
            if(this.allEmployees.get(i) instanceof TempWorker) {
                out+=this.allEmployees.get(i)+"\n";
            }
        }
        return out;
    }
    
    public double calcPayForAllEmployees() {
        double out = 0;
        for(int i=0; i< this.allEmployees.size(); i++) {
            out+=this.allEmployees.get(i).calcPay();
        }
        return out;
}
}