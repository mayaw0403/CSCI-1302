package assignment;

public class GradedCourse extends Course{
	//See Assignment 3 or "High Level View of Your Tasks" in Folio to see what Course contains

	/**
	 * The course awards a letter Grade 
	 * The numeric score to letter grade is based on the values provided in the constructor. 
	 * (Remember that the Student class has computeMyAverage as a method)
	 * @return the number of students who's average of all the student's quizzes is at or better then the score that maps to the letter grade
	 * e.g. (notice the extra newline at the beginning)


		1 students on track for A
		4 students on track for B
		7 students on track for C
		2 students on track for D
	 
	 */
	private double minScoreForA;
	private double minScoreForB;
	private double minScoreForC;
	private double minScoreForD;
	
	public double getMinScoreForA() {
		return minScoreForA;
	}
	public void setMinScoreForA(double minScoreForA) {
		this.minScoreForA = minScoreForA;
	}
	public double getMinScoreForB() {
		return minScoreForB;
	}
	public void setMinScoreForB(double minScoreForB) {
		this.minScoreForB = minScoreForB;
	}
	public double getMinScoreForC() {
		return minScoreForC;
	}
	public void setMinScoreForC(double minScoreForC) {
		this.minScoreForC = minScoreForC;
	}
	public double getMinScoreForD() {
		return minScoreForD;
	}
	public void setMinScoreForD(double minScoreForD) {
		this.minScoreForD = minScoreForD;
	}
	public String countABCDFStudents() {
		int countA = 0, countB = 0, countC = 0, countD = 0;

		for (Student student : getAllStudents()) {
			double avg = student.computeMyAverage();
			if (avg >= minScoreForA) {
				countA++;
				} else if (avg >= minScoreForB && avg < minScoreForA) {
					countB++;
					} else if (avg >= minScoreForC && avg < minScoreForB) {
						countC++;
						} else if (avg >= minScoreForD && avg < minScoreForC) {
							countD++;
							}
			}

		return "\n" + countA + " students on track for A\n" + countB + " students on track for B\n" + countC
		+ " students on track for C\n" + countD + " students on track for D\n";
	}
	/**
	 * Name of this Graded Course
	 * @param courseName
	 */
	public GradedCourse(String courseName, double minScoreForA, double minScoreForB, double minScoreForC, double minScoreForD) {
		super(courseName);
		this.minScoreForA = minScoreForA;
		this.minScoreForB = minScoreForB;
		this.minScoreForC = minScoreForC;
		this.minScoreForD = minScoreForD;
		
	}
	
	/**
	 * @return a string that mentions the course name, type of course, number of students in A,B,C,D, and the super's toString
	 * e.g. 

		Underwater Basket Weaving is a letter grade course. 
		1 students on track for A
		1 students on track for B
		1 students on track for C
		1 students on track for D

		Students in this course:
		[Bugsy 521, Daisy 321, Minny 876, Mikey 543]
		
	 */
	public String toString() {
		return super.getCourseName() + " is a letter grade course. " + countABCDFStudents() + "\n" + super.toString();
	}
	
}

