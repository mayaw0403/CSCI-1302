package assignment;

public class TempWorker implements Employee{
		private String name; // employee name
		private int id; // employee id
		private double payRate; // employee pay rate (per hour)
		private double hoursWorked; // employee number of hours worked
		
		/**
		 * 2-arg constructor to initialize the name and id of employee to parameters
		 * and sets payRate and hoursWorked to 0.
		 * @param nameOfEmp
		 * @param id
		 */
		public TempWorker(String nameOfEmp, int id) {
			
			name = nameOfEmp;
			this.id = id;
		}
		  
		/**
		 * Calculate the pay due to the employee based on rate and hours worked.
		 * Include overtime pay (over 40 hours) in calculation: Hourly pay rate x 1.5 x overtime hours worked.
		 */
		@Override
		public double calcPay() {
			
			// number of hours worked is greater than 40, return total pay as regular pay for 40 hours worked and all hours above 40 as overtime pay
			if(hoursWorked > 40)
				return (40*payRate) + (hoursWorked-40) * 1.5 * payRate;
			else // else return total pay as regular pay for hoursWorked
				return hoursWorked * payRate;
		}

		/**
		 * Setter for hoursWorked
		 */
		@Override
		public void setHoursWorked(double hrsWrked) {
			hoursWorked = hrsWrked;
		}

		/**
		 * Getter for hoursWorked
		 * @return hoursWorked
		 */
		@Override
		public double getHoursWorked() {
			return hoursWorked;
		}	

		/**
		 * Setter for payRate
		 */
		@Override
		public void setPayRate(double payRate) {
			
			this.payRate = payRate;
		}

		/**
		 * Getter for payRate
		 * @return payRate
		 */
		@Override
		public double getPayRate() {
		
			return payRate;
		}

		/**
		 * Getter for id
		 * @return id
		 */
		@Override
		public int getId() {
			return id;
		}

		/**
		 * Getter for name
		 * @return name
		 */
		public String getNameOfEmp() {
			return name;
		}

		/**
		 * Setter for name
		 * @param nameOfEmp
		 */
		public void setNameOfEmp(String nameOfEmp) {
			name = nameOfEmp;
		}

		/**
		 * @return String that mentions the employee's name, id, and the pay for the period
		 * e.g.

		       Daisy 321 - pay for this period is $500.00

		 */
		public String toString() {
			
			// return total pay that has 2 decimal places
			return String.format("%s %d - pay for this period is $%.2f",name, id, calcPay());
		}

	}