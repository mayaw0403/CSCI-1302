package assignment;

public class PassFailCourse extends Course {
	//See Assignment 3 or "High Level View of Your Tasks" in Folio to see what Course contains
	
	String courseName;
	
	/**
	* This overrides Course's computerCourseAverage method.
	* The course is Pass / Fail, which means you will not receive a specific grade.
	* however, you need a 75% average to pass the course.
	* (Remember that the Student class has computeMyAverage as a method)
	* @return the number of students who's average of all the student's quizzes is 75% or better divided by the total students in the course
	*/
	@Override
	public double computeCourseAverage() {

	//counter created for passing students
	double countP = 0.0;
	double pass = 75.0;

	//for loop to see each student's average is what letters grade
	//increase the count for this
	for (int i = 0; i < getAllStudents().size(); i++) {

	//need to call computeMyAverage method of the Student class
	double avg = getAllStudents().get(i).computeMyAverage();

	//if statements will increase counter for passing if student's average is at or above the value of 75%
	if (getAllStudents().get(i).computeMyAverage() >= pass) {
		countP++;
		}
	}
	//return method
	return (countP/getAllStudents().size()) * 100;

	}

	public PassFailCourse(String courseName) {
		super(courseName);
	}

	public String toString() {
		return super.getCourseName() + " is a pass/fail course. " + computeCourseAverage() + "0% of the class are on track to pass the course. " + super.toString();
	}

}

