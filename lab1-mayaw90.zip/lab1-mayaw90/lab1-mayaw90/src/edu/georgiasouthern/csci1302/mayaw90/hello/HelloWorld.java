package edu.georgiasouthern.csci1302.mayaw90.hello;

public class HelloWorld {

	public static void main(String[] args) {
        System.out.println("Hello, GitHub!");
    } // main(String[])

}
